---@meta
local resty_core_var = {}
resty_core_var.version = require("resty.core.base").version
return resty_core_var
