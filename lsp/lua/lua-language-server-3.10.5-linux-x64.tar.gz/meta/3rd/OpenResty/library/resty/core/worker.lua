---@meta
local resty_core_worker = {}
resty_core_worker._VERSION = require("resty.core.base").version
return resty_core_worker
