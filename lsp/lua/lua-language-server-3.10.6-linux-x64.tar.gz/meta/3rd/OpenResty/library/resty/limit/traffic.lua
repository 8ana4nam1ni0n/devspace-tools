---@meta
resty_limit_traffic = {}
resty_limit_traffic._VERSION = "0.06"
function resty_limit_traffic.combine(limiters, keys, states) end
return resty_limit_traffic
