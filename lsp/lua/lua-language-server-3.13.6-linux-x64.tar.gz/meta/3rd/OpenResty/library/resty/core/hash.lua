---@meta
local resty_core_hash = {}
resty_core_hash.version = require("resty.core.base").version
return resty_core_hash
