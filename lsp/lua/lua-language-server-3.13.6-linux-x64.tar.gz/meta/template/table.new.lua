---#if not JIT then DISABLE() end
---@meta table.new

---@version JIT
---#DES 'table.new'
---@param narray integer
---@param nhash integer
---@return table
local function new(narray, nhash) end

return new
