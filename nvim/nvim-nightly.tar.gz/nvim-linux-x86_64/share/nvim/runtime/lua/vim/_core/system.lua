local strbuffer = require('vim._core.stringbuffer')
local uv = vim.uv
local M = {}

--- @class vim.SystemOpts
--- @inlinedoc
---
--- Set the current working directory for the sub-process.
--- @field cwd? string
---
--- Set environment variables for the new process. Inherits the current environment with `NVIM` set
--- to |v:servername|.
--- @field env? table<string,string|number>
---
--- `env` defines the job environment exactly, instead of merging current environment. Note: if
--- `env` is `nil`, the current environment is used but without `NVIM` set.
--- @field clear_env? boolean
---
--- If `true`, then a pipe to stdin is opened and can be written to via the `write()` method to
--- SystemObj. If `string` or `string[]` then will be written to stdin and closed.
--- @field stdin? string|string[]|true
---
--- Handle output from stdout.
--- (Default: `true`)
--- @field stdout? fun(err:string?, data: string?)|boolean
---
--- Handle output from stderr.
--- (Default: `true`)
--- @field stderr? fun(err:string?, data: string?)|boolean
---
--- Handle stdout and stderr as text. Normalizes line endings by replacing `\r\n` with `\n`.
--- @field text? boolean
---
--- Run the command with a time limit (ms). Upon timeout the process is stopped
--- (|SystemObj:close()|) and exit code is 124.
--- @field timeout? integer
---
--- Spawn the child process in a detached state - this will make it a process group leader, and will
--- effectively enable the child to keep running after the parent exits. Note that the child process
--- will still keep the parent's event loop alive unless the parent process calls [uv.unref()] on
--- the child's process handle.
--- @field detach? boolean

--- @class vim.SystemCompleted
--- @field code integer
--- @field signal integer
--- @field stdout? string `nil` if stdout is disabled or has a custom handler.
--- @field stderr? string `nil` if stderr is disabled or has a custom handler.

--- @class (package) vim.SystemState
--- @field cmd string[]
--- @field handle? uv.uv_process_t
--- @field timer?  uv.uv_timer_t
--- @field pid? integer
--- @field timeout? integer
--- @field stopped? 'timeout'|'close' Set when a timeout or `close()` stops the process.
--- @field stdin? uv.uv_stream_t
--- @field stdout? uv.uv_stream_t
--- @field stderr? uv.uv_stream_t
--- @field stdout_handler? fun(err: string?, data: string?) Reads `stdout`; closes it on EOF (nil).
--- @field stderr_handler? fun(err: string?, data: string?) Reads `stderr`; closes it on EOF (nil).
--- @field stdout_data? vim._core.stringbuffer
--- @field stderr_data? vim._core.stringbuffer
--- @field exit? { code: integer, signal: integer } Exit status, set when the process exits.
--- @field result? vim.SystemCompleted Set after the process exits and its output pipes close.
--- @field on_close? fun()[] Callbacks of `close()`, called after the process exits.

--- @enum vim.SystemSig
local SIG = {
  HUP = 1, -- Hangup
  INT = 2, -- Interrupt from keyboard
  KILL = 9, -- Kill signal
  TERM = 15, -- Termination signal
  -- STOP = 17,19,23  -- Stop the process
}

---@param handle uv.uv_handle_t?
local function close_handle(handle)
  if handle and not handle:is_closing() then
    handle:close()
  end
end

--- @param timeout integer
--- @param cb fun()
--- @return uv.uv_timer_t
local function timer_oneshot(timeout, cb)
  local timer = assert(uv.new_timer())
  uv.update_time() -- See time_watcher_start().
  timer:start(timeout, 0, function()
    timer:stop()
    timer:close()
    cb()
  end)
  return timer
end

--- Gets the result from the exit status and the output read so far.
--- @param state vim.SystemState
--- @return vim.SystemCompleted
local function completed(state)
  local exit = assert(state.exit)
  local code = exit.code
  if (code == 0 or code == 1) and state.stopped == 'timeout' then
    code = 124 -- Stopped: code 0 (Unix) or 1 (Windows).
  end
  return {
    code = code,
    signal = exit.signal,
    stdout = state.stdout_data and state.stdout_data:tostring() or nil,
    stderr = state.stderr_data and state.stderr_data:tostring() or nil,
  }
end

--- Closes output pipes without waiting for EOF, which a descendant process may otherwise delay
--- indefinitely. Calls each pipe's handler with `nil` data, as EOF would.
--- @param state vim.SystemState
local function end_output(state)
  if state.stdout and not state.stdout:is_closing() then
    assert(state.stdout_handler)(nil, nil)
  end
  if state.stderr and not state.stderr:is_closing() then
    assert(state.stderr_handler)(nil, nil)
  end
end

--- @class vim.SystemObj
--- @field cmd string[] Command name and args
--- @field pid integer Process ID
--- @field package _state vim.SystemState
local SystemObj = {}

--- @param state vim.SystemState
--- @return vim.SystemObj
local function new_systemobj(state)
  return setmetatable({
    cmd = state.cmd,
    pid = state.pid,
    _state = state,
  }, { __index = SystemObj })
end

--- Sends a signal to the process.
---
--- The signal can be specified as an integer or as a string.
---
--- Example:
--- ```lua
--- local obj = vim.system({'sleep', '10'})
--- obj:kill('sigterm') -- sends SIGTERM to the process
--- ```
---
--- @param signal integer|string Signal to send to the process. See |luv-constants|.
function SystemObj:kill(signal)
  assert(self._state.handle):kill(signal)
end

--- Stops the process (SIGTERM, escalates to SIGKILL after 2s). On process-exit, closes its output
--- pipes without waiting for EOF (see `on_exit`), and calls `on_close`. Implements
--- |vim.async.Closable|, so closing a task that awaits |vim.system()| stops the process.
---
--- Example:
--- ```lua
--- local task = vim.async.run(function()
---   return vim.async.await(3, vim.system, { 'sleep', '10' }, {})
--- end)
--- task:close() -- Stops `sleep`.
--- ```
---
--- @param on_close? fun()
function SystemObj:close(on_close)
  local state = self._state
  if state.result then -- Exited already.
    if on_close then
      on_close()
    end
    return
  end
  if on_close then
    state.on_close = state.on_close or {}
    table.insert(state.on_close, on_close)
  end
  state.stopped = state.stopped or 'close'
  if state.exit then
    end_output(state) -- Exited already (see `_on_exit()`).
  elseif state.handle and state.handle:is_active() then
    self:kill(SIG.TERM)
    close_handle(state.timer) -- Stopping anyway: replaces the `timeout` timer.
    state.timer = timer_oneshot(2000, function()
      if state.handle and state.handle:is_active() then
        self:kill(SIG.KILL)
      end
    end)
  end
end

--- @package
function SystemObj:_timeout()
  if self._state.handle and self._state.handle:is_active() then
    self._state.stopped = 'timeout'
    self:close()
  end
end

--- Waits for the process to complete, and stops it on timeout or CTRL-C.
---
--- Blocks until the process exits and its output pipes close, or until `timeout` (ms) or CTRL-C.
--- If `timeout` is not given it defaults to `opts.timeout`, else waits indefinitely.
---
--- On timeout:
--- - Stops the process (|SystemObj:close()|) if it is running, and sets exit code 124.
--- - Waits for process exit (max 2s, escalates to SIGKILL), but not its output pipes (a descendant
---   may inherit them and keep them open, e.g. a browser started by `xdg-open`).
--- - Returns the output collected so far.
---
--- On CTRL-C:
--- - Stops the process (see above).
--- - Raises error "interrupted".
---
--- Example:
--- ```lua
--- local obj = vim.system({'echo', 'hello'}, { text = true })
--- local result = obj:wait(1000) -- waits up to 1000ms
--- print(result.code, result.signal, result.stdout, result.stderr)
---
--- -- Monitor a long-lived process that prints "READY".
--- local result = vim.system({ 'ssh', '-L', … }):wait(nil, function(stdout)
---   return stdout:find('READY') ~= nil
--- end)
--- ```
---
--- @param timeout? integer Wait duration (ms).
--- @param cond? fun(stdout: string, stderr: string): boolean Stops waiting when it returns true,
--- without terminating the process. The `stdout` and `stderr` args have the accumulated output so
--- far. The result has no `code` or `signal`.
--- @return vim.SystemCompleted
function SystemObj:wait(timeout, cond)
  local state = self._state

  --- @param buf? vim._core.stringbuffer
  local function output(buf)
    return buf and buf:tostring() or nil
  end
  local done, err = vim.wait(timeout or state.timeout or vim._maxint, function()
    return state.result ~= nil
      or (cond ~= nil and cond(output(state.stdout_data) or '', output(state.stderr_data) or ''))
  end, 200, true)

  if done and not state.result then
    return { stdout = output(state.stdout_data), stderr = output(state.stderr_data) } --[[@as vim.SystemCompleted]]
  end

  if not done then
    if err == -2 then -- CTRL-C.
      self:close()
      error('interrupted', 0)
    end
    self:_timeout()
    -- Exits within 2s (see `close()`).
    done, err = vim.wait(vim._maxint, function()
      return state.exit ~= nil
    end, nil, true)
    if err == -2 then
      error('interrupted', 0)
    end
  end

  return state.result or completed(state)
end

--- Writes data to the stdin of the process or closes stdin.
---
--- If `data` is a list of strings, each string is written followed by a
--- newline.
---
--- If `data` is a string, it is written as-is.
---
--- If `data` is `nil`, the write side of the stream is shut down and the pipe
--- is closed.
---
--- Example:
--- ```lua
--- local obj = vim.system({'cat'}, { stdin = true })
--- obj:write({'hello', 'world'}) -- writes 'hello\nworld\n' to stdin
--- obj:write(nil) -- closes stdin
--- ```
---
--- @param data string[]|string|nil
function SystemObj:write(data)
  local stdin = self._state.stdin

  if not stdin then
    error('stdin has not been opened on this object')
  end

  if type(data) == 'table' then
    for _, v in ipairs(data) do
      stdin:write(v)
      stdin:write('\n')
    end
  elseif type(data) == 'string' then
    stdin:write(data)
  elseif data == nil then
    -- Shutdown the write side of the duplex stream and then close the pipe.
    -- Note shutdown will wait for all the pending write requests to complete
    -- TODO(lewis6991): apparently shutdown doesn't behave this way.
    -- (https://github.com/neovim/neovim/pull/17620#discussion_r820775616)
    stdin:write('', function()
      stdin:shutdown(function()
        close_handle(stdin)
      end)
    end)
  end
end

--- Checks if the process handle is closing or already closed.
---
--- This method returns `true` if the underlying process handle is either
--- `nil` or is in the process of closing. It is useful for determining
--- whether it is safe to perform operations on the process handle.
---
--- @return boolean
function SystemObj:is_closing()
  local handle = self._state.handle
  return handle == nil or handle:is_closing() or false
end

--- @param output? fun(err: string?, data: string?)|boolean
--- @param text? boolean
--- @return uv.uv_stream_t? pipe
--- @return integer? child_fd
--- @return fun(err: string?, data: string?)? handler
--- @return vim._core.stringbuffer? data
local function setup_output(output, text)
  if output == false then
    return
  end

  local bucket --- @type vim._core.stringbuffer?
  local handler --- @type fun(err: string?, data: string?)

  if type(output) == 'function' then
    handler = output
  else
    local buf = strbuffer.new()
    bucket = buf
    --- @param err string?
    --- @param data string?
    handler = function(err, data)
      if err then
        error(err)
      end
      if data then
        buf:put(text and (data:gsub('\r\n', '\n')) or data)
      end
    end
  end

  --- @diagnostic disable-next-line:missing-fields,param-type-mismatch luvit/luv#827
  local pipe_fd = assert(uv.pipe({ nonblock = true }, {}))
  local pipe = assert(uv.new_pipe(false))
  pipe:open(pipe_fd.read)

  --- @param err? string
  --- @param data? string
  local function handler_with_close(err, data)
    handler(err, data)
    if data == nil then
      pipe:read_stop()
      pipe:close()
    end
  end

  return pipe, pipe_fd.write, handler_with_close, bucket
end

--- @param input? string|string[]|boolean
--- @return uv.uv_stream_t?
--- @return integer? child_fd
--- @return string|string[]?
local function setup_input(input)
  if not input then
    return
  end

  local towrite --- @type string|string[]?
  if type(input) == 'string' or type(input) == 'table' then
    towrite = input
  end

  --- @diagnostic disable-next-line:missing-fields,param-type-mismatch luvit/luv#827
  local pipe_fd = assert(uv.pipe({}, { nonblock = true }))
  local pipe = assert(uv.new_pipe(false))
  pipe:open(pipe_fd.write)

  return pipe, pipe_fd.read, towrite
end

--- @return table<string,string>
local function base_env()
  local env = vim.fn.environ() --- @type table<string,string>
  env['NVIM'] = vim.v.servername
  env['NVIM_LISTEN_ADDRESS'] = nil
  return env
end

--- uv.spawn will completely overwrite the environment
--- when we just want to modify the existing one, so
--- make sure to prepopulate it with the current env.
--- @param env? table<string,string|number>
--- @param clear_env? boolean
--- @return string[]?
local function setup_env(env, clear_env)
  if not env and clear_env then
    return
  end

  env = env or {}
  if not clear_env then
    --- @type table<string,string|number>
    env = vim.tbl_extend('force', base_env(), env)
  end

  local renv = {} --- @type string[]
  for k, v in pairs(env) do
    renv[#renv + 1] = string.format('%s=%s', k, tostring(v))
  end

  return renv
end

local is_win = vim.fn.has('win32') == 1

--- @class (private) vim.SystemSpawnOpts : uv.spawn.options
--- @field stdio [integer?, integer?, integer?]

--- @param cmd string
--- @param opts vim.SystemSpawnOpts
--- @param on_exit fun(code: integer, signal: integer)
--- @param on_error fun()
--- @return uv.uv_process_t, integer
local function spawn(cmd, opts, on_exit, on_error)
  if is_win then
    local cmd1 = vim.fn.exepath(cmd)
    if cmd1 ~= '' then
      -- Use native separators when launching a resolved Windows executable.
      cmd = cmd1:gsub('/', '\\')
    end
  end

  local handle, pid_or_err = uv.spawn(cmd, opts, on_exit)
  -- close child stdio fd:s regardless of error
  for i = 1, 3 do
    local fd = opts.stdio[i]
    if fd then
      uv.fs_close(fd)
    end
  end

  if not handle then
    on_error()
    if opts.cwd and not uv.fs_stat(opts.cwd) then
      error(("%s (cwd): '%s'"):format(pid_or_err, opts.cwd))
    elseif vim.fn.executable(cmd) == 0 then
      error(("%s (cmd): '%s'"):format(pid_or_err, cmd))
    else
      error(pid_or_err)
    end
  end
  return handle, pid_or_err --[[@as integer]]
end

--- @param state vim.SystemState
--- @param code integer
--- @param signal integer
--- @param on_exit fun(result: vim.SystemCompleted)?
local function _on_exit(state, code, signal, on_exit)
  state.exit = { code = code, signal = signal }
  close_handle(state.handle)
  close_handle(state.stdin)
  close_handle(state.timer)

  -- #30846: Do not close stdout/stderr here, as they may still have data to read. They close on EOF,
  -- or if the process was stopped, in the check below: after the event-loop poll that reported the
  -- exit, which also read the output that the process wrote.
  local check = uv.new_check()
  check:start(function()
    if state.stopped then
      end_output(state)
    end
    for _, pipe in pairs({ state.stdin, state.stdout, state.stderr }) do
      if not pipe:is_closing() then
        return
      end
    end
    check:stop()
    check:close()

    state.result = completed(state)

    for _, on_close in ipairs(state.on_close or {}) do
      on_close()
    end
    if on_exit then
      on_exit(state.result)
    end
  end)
end

--- @param state vim.SystemState
local function _on_error(state)
  close_handle(state.handle)
  close_handle(state.stdin)
  close_handle(state.stdout)
  close_handle(state.stderr)
  close_handle(state.timer)
end

--- Run a system command
---
--- @param cmd string[]
--- @param opts? vim.SystemOpts
--- @param on_exit? fun(out: vim.SystemCompleted)
--- @return vim.SystemObj
local function run(cmd, opts, on_exit)
  vim.validate('cmd', cmd, function(v)
    return type(v) == 'table' and type(v[1]) == 'string'
  end, 'non-empty list of strings')
  --- @cast cmd string[] & { [1]: string }
  vim.validate('opts', opts, 'table', true)
  vim.validate('on_exit', on_exit, 'function', true)

  opts = opts or {}

  local stdout, stdout_child_fd, stdout_handler, stdout_data = setup_output(opts.stdout, opts.text)
  local stderr, stderr_child_fd, stderr_handler, stderr_data = setup_output(opts.stderr, opts.text)
  local stdin, stdin_child_fd, towrite = setup_input(opts.stdin)

  --- @type vim.SystemState
  local state = {
    cmd = cmd,
    timeout = opts.timeout,
    stdin = stdin,
    stdout = stdout,
    stdout_data = stdout_data,
    stdout_handler = stdout_handler,
    stderr = stderr,
    stderr_data = stderr_data,
    stderr_handler = stderr_handler,
  }

  state.handle, state.pid = spawn(cmd[1], {
    args = vim.list_slice(cmd, 2),
    -- local function spawn() will close these
    stdio = { stdin_child_fd, stdout_child_fd, stderr_child_fd },
    cwd = opts.cwd,
    env = setup_env(opts.env, opts.clear_env),
    detached = opts.detach,
    hide = true,
  }, function(code, signal)
    _on_exit(state, code, signal, on_exit)
  end, function()
    _on_error(state)
  end)

  if stdout and stdout_handler then
    stdout:read_start(stdout_handler)
  end

  if stderr and stderr_handler then
    stderr:read_start(stderr_handler)
  end

  local obj = new_systemobj(state)

  if towrite then
    obj:write(towrite)
    obj:write(nil) -- close the stream
  end

  if opts.timeout then
    state.timer = timer_oneshot(opts.timeout, function()
      obj:_timeout()
    end)
  end

  return obj
end

--- Runs a system command or throws an error if {cmd} cannot be run.
---
--- The command runs directly (not in 'shell') so shell builtins such as "echo" in cmd.exe, cmdlets
--- in powershell, or "help" in bash, will not work unless you actually invoke a shell:
--- `vim.system({'bash', '-c', 'help'})`.
---
--- Examples:
---
--- ```lua
--- local on_exit = function(obj)
---   print(obj.code)
---   print(obj.signal)
---   print(obj.stdout)
---   print(obj.stderr)
--- end
---
--- -- Runs asynchronously:
--- vim.system({'echo', 'hello'}, { text = true }, on_exit)
---
--- -- Runs synchronously:
--- local obj = vim.system({'echo', 'hello'}, { text = true }):wait()
--- -- { code = 0, signal = 0, stdout = 'hello\n', stderr = '' }
---
--- ```
---
--- See |uv.spawn()| for more details. Note: unlike |uv.spawn()|, vim.system
--- throws an error if {cmd} cannot be run.
---
--- @param cmd string[] Command to execute
--- @param opts vim.SystemOpts?
--- @param on_exit? fun(out: vim.SystemCompleted) Called with the result on process exit and output
---   pipes closed. Delayed (possibly indefinitely) if a descendant process inherits the pipes and
---   does not close them (e.g. `cmd &` in a shell script). Note that |SystemObj:close()| closes
---   pipes, thus ensuring `on_exit` is called.
---
--- @return vim.SystemObj
--- @overload fun(cmd: string[], on_exit: fun(out: vim.SystemCompleted)): vim.SystemObj
function vim.system(cmd, opts, on_exit)
  if type(opts) == 'function' then
    on_exit = opts
    opts = nil
  end
  return run(cmd, opts, on_exit)
end

return M
