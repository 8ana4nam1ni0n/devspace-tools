--- @meta
-- This file is NOT generated, edit it directly.
error('Cannot require a meta file')

vim.base64 = {}

--- Encode {str} using Base64.
---
--- @param str string String to encode
--- @return string : Encoded string
function vim.base64.encode(str) end

--- Decode a Base64 encoded string.
---
--- @param str string Base64 encoded string
--- @return string : Decoded string
function vim.base64.decode(str) end
