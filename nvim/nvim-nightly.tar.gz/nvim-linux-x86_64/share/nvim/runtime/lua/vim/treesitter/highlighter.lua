local api = vim.api
local query = vim.treesitter.query
local Range = require('vim.treesitter._range')
local cmp_lt = Range.cmp_pos.lt
local cmp_ge = Range.cmp_pos.ge

local ns = api.nvim_create_namespace('nvim.treesitter.highlighter')
-- Intra-line conceal, apart from `ns`, where on_range_impl() looks up `conceal_lines` marks.
local conceal_ns = api.nvim_create_namespace('nvim.treesitter.highlighter.conceal')

---@alias vim.treesitter.highlighter.Iter fun(end_line: integer|nil, end_col: integer|nil): integer, TSNode, vim.treesitter.query.TSMetadata, TSQueryMatch, TSTree

---@class (private) vim.treesitter.highlighter.Query
---@field private _query vim.treesitter.Query?
---@field private lang string
---@field private hl_cache table<integer,integer>
local TSHighlighterQuery = {}
TSHighlighterQuery.__index = TSHighlighterQuery

---@private
---@param lang string
---@param query_string string?
---@return vim.treesitter.highlighter.Query
function TSHighlighterQuery.new(lang, query_string)
  local self = setmetatable({}, TSHighlighterQuery)
  self.lang = lang
  self.hl_cache = {}

  if query_string then
    self._query = query.parse(lang, query_string)
  else
    self._query = query.get(lang, 'highlights')
  end

  return self
end

---@package
---@param capture integer
---@return integer?
function TSHighlighterQuery:get_hl_from_capture(capture)
  if not self.hl_cache[capture] then
    local name = assert(assert(self._query).captures[capture])
    local id = 0
    if not vim.startswith(name, '_') then
      id = api.nvim_get_hl_id_by_name('@' .. name .. '.' .. self.lang)
    end
    self.hl_cache[capture] = id
  end

  return self.hl_cache[capture]
end

---@nodoc
function TSHighlighterQuery:query()
  return self._query
end

---@class (private) vim.treesitter.highlighter.State
---@field tstree TSTree
---@field root_range Range4
---@field next_row integer
---@field next_col integer
---@field iter vim.treesitter.highlighter.Iter?
---@field highlighter_query vim.treesitter.highlighter.Query

---@nodoc
---@class vim.treesitter.highlighter
---@field active table<integer,vim.treesitter.highlighter>
---@field bufnr integer
---@field private orig_spelloptions string
--- A map from window ID to highlight states.
--- This state is kept during rendering across each line update.
---@field private _highlight_states vim.treesitter.highlighter.State[]
---@field private _queries table<string,vim.treesitter.highlighter.Query>
--- Whether a query of the tree can conceal text. Only turns on: a row parse drops the injected
--- trees outside the row.
---@field  _has_conceal boolean
--- Like `_has_conceal`, for `conceal_lines`.
---@field  _has_conceal_line boolean
--- Rows whose conceal is in the marktree (see `TSHighlighter._on_conceal()`): `true` with
--- intra-line conceal, `false` with only `conceal_lines`.
---@field  _conceal_checked table<integer, boolean>
---@field tree vim.treesitter.LanguageTree
---@field private redraw_count integer
--- A map from window ID to whether we are currently parsing that window asynchronously
---@field parsing boolean
local TSHighlighter = {
  active = {},
}

TSHighlighter.__index = TSHighlighter

---@nodoc
---
--- Creates a highlighter for `tree`.
---
---@param tree vim.treesitter.LanguageTree parser object to use for highlighting
---@param opts (table|nil) Configuration of the highlighter:
---           - queries table overwrite queries used by the highlighter
---@return vim.treesitter.highlighter Created highlighter object
function TSHighlighter.new(tree, opts)
  local source = tree:source()
  if type(source) ~= 'number' then
    error('TSHighlighter can not be used with a string parser source.')
  end

  -- Reuse the highlighter rather than registering duplicate callbacks.
  local existing = TSHighlighter.active[source]
  if existing then
    if existing.tree == tree then
      return existing
    end
    existing:destroy()
  end

  local self = setmetatable({}, TSHighlighter)

  opts = opts or {} ---@type { queries: table<string,string> }
  self.tree = tree
  tree:register_cbs({
    on_detach = function()
      self:on_detach()
    end,
  })

  --- Sets `_has_conceal` and `_has_conceal_line` from the queries of all trees.
  local function update_conceal_metadata()
    local has_conceal_line = self._has_conceal_line
    local has_conceal = self._has_conceal
    ---@param lang_tree vim.treesitter.LanguageTree
    local function visit(lang_tree)
      local q = self:get_query(lang_tree:lang()):query()
      has_conceal_line = has_conceal_line or q ~= nil and q.has_conceal_line == true
      has_conceal = has_conceal or q ~= nil and q.has_conceal == true
      for _, child in pairs(lang_tree:children()) do
        visit(child)
      end
    end
    visit(self.tree)
    if self._has_conceal_line ~= has_conceal_line or self._has_conceal ~= has_conceal then
      self._conceal_checked = {}
    end
    if has_conceal and not self._has_conceal then
      api.nvim__buf_set_conceal_provider(self.bufnr, true)
    end
    self._has_conceal_line = has_conceal_line
    self._has_conceal = has_conceal
  end

  tree:register_cbs({
    on_bytes = function(buf, _, start_row, _, _, old_row, _, _, new_row)
      if TSHighlighter.active[buf] ~= self then
        return
      end
      -- Recheck the edited rows; the rows below move along with their marks, and on_changedtree()
      -- rechecks rows whose syntax changed.
      if old_row == new_row then
        for row = start_row, start_row + new_row do
          self._conceal_checked[row] = nil
        end
        return
      end
      local checked = {} ---@type table<integer, boolean>
      for row, v in pairs(self._conceal_checked) do
        if row < start_row then
          checked[row] = v
        elseif row > start_row + old_row then
          checked[row + new_row - old_row] = v
        end
      end
      self._conceal_checked = checked
    end,
    on_changedtree = function(...)
      self:on_changedtree(...)
    end,
    on_child_removed = function(child)
      if TSHighlighter.active[self.bufnr] ~= self then
        return
      end
      child:for_each_tree(function(t)
        self:on_changedtree(t:included_ranges(true))
      end)
    end,
    on_child_added = function()
      if TSHighlighter.active[self.bufnr] ~= self then
        return
      end
      update_conceal_metadata()
    end,
  }, true)

  self.bufnr = source
  self.redraw_count = 0
  self._has_conceal = false
  self._has_conceal_line = false
  self._conceal_checked = {}
  self._queries = {}
  self._highlight_states = {}
  self.parsing = false

  -- Queries for a specific language can be overridden by a custom
  -- string query... if one is not provided it will be looked up by file.
  if opts.queries then
    for lang, query_string in pairs(opts.queries) do
      self._queries[lang] = TSHighlighterQuery.new(lang, query_string)
    end
  end
  update_conceal_metadata()
  self.orig_spelloptions = vim.bo[self.bufnr].spelloptions

  vim.bo[self.bufnr].syntax = ''
  vim.b[self.bufnr].ts_highlight = true

  TSHighlighter.active[self.bufnr] = self

  -- Tricky: if syntax hasn't been enabled, we need to reload color scheme
  -- but use synload.vim rather than syntax.vim to not enable
  -- syntax FileType autocmds. Later on we should integrate with the
  -- `:syntax` and `set syntax=...` machinery properly.
  -- Still need to ensure that syntaxset augroup exists, so that calling :destroy()
  -- immediately afterwards will not error.
  if vim.g.syntax_on ~= 1 then
    vim.cmd.runtime({ 'syntax/synload.vim', bang = true })
    api.nvim_create_augroup('syntaxset', { clear = false })
  end

  vim._with({ buf = self.bufnr }, function()
    vim.opt_local.spelloptions:append('noplainbuffer')
  end)

  return self
end

--- @nodoc
--- Removes all internal references to the highlighter
function TSHighlighter:destroy()
  if TSHighlighter.active[self.bufnr] ~= self then
    return
  end
  TSHighlighter.active[self.bufnr] = nil

  if self._has_conceal and api.nvim_buf_is_valid(self.bufnr) then
    api.nvim__buf_set_conceal_provider(self.bufnr, false)
  end
  if api.nvim_buf_is_loaded(self.bufnr) then
    vim.bo[self.bufnr].spelloptions = self.orig_spelloptions
    vim.b[self.bufnr].ts_highlight = nil
    api.nvim_buf_clear_namespace(self.bufnr, ns, 0, -1)
    api.nvim_buf_clear_namespace(self.bufnr, conceal_ns, 0, -1)
    if vim.g.syntax_on == 1 then
      api.nvim_exec_autocmds(
        'FileType',
        { group = 'syntaxset', buf = self.bufnr, modeline = false }
      )
    end
  end
end

---@param srow integer
---@param erow integer exclusive
---@private
function TSHighlighter:prepare_highlight_states(srow, erow)
  self._highlight_states = {}

  self.tree:for_each_tree(function(tstree, tree)
    if not tstree then
      return
    end

    local root_node = tstree:root()
    local root_start_row, root_start_col, root_end_row, root_end_col = root_node:range()

    -- Only consider trees within the visible range
    if root_start_row > erow or root_end_row < srow then
      return
    end

    local hl_query = self:get_query(tree:lang())
    -- Some injected languages may not have highlight queries.
    if not hl_query:query() then
      return
    end

    -- _highlight_states should be a list so that the highlights are added in the same order as
    -- for_each_tree traversal. This ensures that parents' highlight don't override children's.
    table.insert(self._highlight_states, {
      tstree = tstree,
      root_range = { root_start_row, root_start_col, root_end_row, root_end_col },
      next_row = 0,
      next_col = 0,
      iter = nil,
      highlighter_query = hl_query,
    })
  end)
end

---@param fn fun(state: vim.treesitter.highlighter.State)
---@package
function TSHighlighter:for_each_highlight_state(fn)
  for _, state in ipairs(self._highlight_states) do
    fn(state)
  end
end

---@package
function TSHighlighter:on_detach()
  self:destroy()
end

---@package
---@param changes Range6[]
function TSHighlighter:on_changedtree(changes)
  if TSHighlighter.active[self.bufnr] ~= self then
    return
  end
  for _, ch in ipairs(changes) do
    api.nvim__redraw({ buf = self.bufnr, range = { ch[1], ch[4] + 1 }, flush = false })
    -- ch[4] is UINT32_MAX for an unbounded range, e.g. on the first parse.
    if ch[4] == 2 ^ 32 - 1 then
      self._conceal_checked = {}
    else
      for i = ch[1], ch[4] do
        self._conceal_checked[i] = nil
      end
    end
  end
end

--- Gets the query used for @param lang
---@nodoc
---@param lang string Language used by the highlighter.
---@return vim.treesitter.highlighter.Query
function TSHighlighter:get_query(lang)
  if not self._queries[lang] then
    local success, result = pcall(TSHighlighterQuery.new, lang)
    if not success then
      self:destroy()
      error(result)
    end
    self._queries[lang] = result
  end

  return self._queries[lang]
end

--- @param match TSQueryMatch
--- @param bufnr integer
--- @param capture integer
--- @param metadata vim.treesitter.query.TSMetadata
--- @return string?
local function get_url(match, bufnr, capture, metadata)
  ---@type string|integer|nil
  local url = metadata[capture] and metadata[capture].url

  if not url or type(url) == 'string' then
    return url
  end

  local captures = match:captures()

  if not captures[url] then
    return
  end

  -- Assume there is only one matching node. If there is more than one, take the URL
  -- from the first.
  local other_node = assert(captures[url][1])

  return vim.treesitter.get_node_text(other_node, bufnr, {
    metadata = metadata[url],
  })
end

--- @param capture_name string
--- @return boolean?, integer
local function get_spell(capture_name)
  if capture_name == 'spell' then
    return true, 0
  elseif capture_name == 'nospell' then
    -- Give nospell a higher priority so it always overrides spell captures.
    return false, 1
  end
  return nil, 0
end

---@param self vim.treesitter.highlighter
---@param buf integer
---@param range_start_row integer
---@param range_start_col integer
---@param range_end_row integer
---@param range_end_col integer
---@param on_spell boolean
---@param on_conceal boolean
---@param on_conceal_intra boolean? Add the intra-line conceal of row `range_start_row`.
local function on_range_impl(
  self,
  buf,
  range_start_row,
  range_start_col,
  range_end_row,
  range_end_col,
  on_spell,
  on_conceal,
  on_conceal_intra
)
  local conceal_range ---@type Range4?
  if on_conceal_intra then
    conceal_range = {
      range_start_row,
      0,
      range_start_row,
      #api.nvim_buf_get_lines(buf, range_start_row, range_start_row + 1, true)[1],
    }
  end

  if self._has_conceal_line then
    range_start_col = 0
    if range_end_col ~= 0 then
      range_end_row = range_end_row + 1
      range_end_col = 0
    end
  end

  local draw_range = { range_start_row, range_start_col, range_end_row, range_end_col }

  local MAX_ROW = 2147483647 -- sentinel for skipping to the end of file
  local skip_until_row = MAX_ROW
  local skip_until_col = 0

  local subtree_counter = 0
  self:for_each_highlight_state(function(state)
    subtree_counter = subtree_counter + 1
    local root_range = state.root_range

    if not Range.intercepts(root_range, draw_range) then
      -- A tree before the range has nothing left to draw, so it must not hold back the skip position.
      if
        cmp_ge(root_range[1], root_range[2], range_end_row, range_end_col)
        and cmp_lt(root_range[1], root_range[2], skip_until_row, skip_until_col)
      then
        skip_until_row = root_range[1]
        skip_until_col = root_range[2]
      end
      return
    end

    local tree_region = state.tstree:included_ranges(true)

    local next_row = state.next_row
    local next_col = state.next_col
    local hl_query = assert(state.highlighter_query:query())

    if state.iter == nil or cmp_lt(next_row, next_col, range_start_row, range_start_col) then
      local root_node = state.tstree:root()
      -- Mainly used to skip over folds

      -- TODO(lewis6991): Creating a new iterator loses the cached predicate results for query
      -- matches. Move this logic inside iter_captures() so we can maintain the cache.
      state.iter = hl_query:iter_captures(
        root_node,
        self.bufnr,
        range_start_row,
        root_range[3],
        { start_col = range_start_col, end_col = root_range[4] }
      )
    end

    local captures = hl_query.captures

    while cmp_lt(next_row, next_col, range_end_row, range_end_col) do
      local capture, node, metadata, match = state.iter(range_end_row, range_end_col)
      if not node then
        next_row = vim._maxint
        next_col = vim._maxint
        break
      end

      local outer_range = vim.treesitter.get_range(node, buf, metadata and metadata[capture])
      if cmp_lt(next_row, next_col, outer_range[1], outer_range[2]) then
        next_row = outer_range[1]
        next_col = outer_range[2]
      end

      if not capture then
        break
      end

      for _, range in ipairs(tree_region) do
        ---@type Range4|Range6|nil
        local intersection = Range.intersection(range, outer_range)
        if intersection then
          local start_row, start_col, end_row, end_col = Range.unpack4(intersection)

          local hl = state.highlighter_query:get_hl_from_capture(capture)

          local capture_name = assert(captures[capture])

          local spell, spell_pri_offset = get_spell(capture_name)

          -- The "conceal" attribute can be set at the pattern level or on a particular capture
          local conceal = metadata.conceal ---@type boolean|string?
          if conceal == nil and metadata[capture] then
            conceal = metadata[capture].conceal
          end
          if capture_name == 'noconceal' then
            conceal = false
          end
          local conceal_pri_offset = conceal == false and 1 or 0

          -- The "priority" attribute can be set at the pattern level or on a particular capture
          local priority = (
            vim._tointeger(metadata.priority or metadata[capture] and metadata[capture].priority)
            or vim.hl.priorities.treesitter
          )
            + spell_pri_offset
            + conceal_pri_offset

          local url = get_url(match, buf, capture, metadata)

          if hl and not on_conceal and (not on_spell or spell ~= nil) then
            -- Workaround for #35814: ensure the range is within buffer bounds,
            -- allowing the last line if end_col is 0.
            -- TODO(skewb1k): investigate a proper concurrency-safe handling of extmarks.
            if (end_row + (end_col > 0 and 1 or 0)) <= api.nvim_buf_line_count(buf) then
              api.nvim_buf_set_extmark(buf, ns, start_row, start_col, {
                end_row = end_row,
                end_col = end_col,
                hl_group = hl,
                ephemeral = true,
                priority = priority,
                conceal = conceal,
                spell = spell,
                url = url,
                _subpriority = subtree_counter,
              })
            end
          end

          if
            (metadata.conceal_lines or metadata[capture] and metadata[capture].conceal_lines)
            and #api.nvim_buf_get_extmarks(buf, ns, { start_row, 0 }, { start_row, 0 }) == 0
          then
            api.nvim_buf_set_extmark(buf, ns, start_row, 0, {
              -- Inclusive, unlike the capture's end: a capture ending at column 0 excludes that row.
              end_line = end_col == 0 and math.max(start_row, end_row - 1) or end_row,
              conceal_lines = '',
            })
          end

          -- Clip only intra-line conceal; conceal_lines needs the full capture range.
          if conceal_range and hl and conceal ~= nil then
            local intra_range =
              Range.intersection({ start_row, start_col, end_row, end_col }, conceal_range)
            if intra_range then
              local sr, sc, er, ec = Range.unpack4(intra_range)
              api.nvim_buf_set_extmark(buf, conceal_ns, sr, sc, {
                end_row = er,
                end_col = ec,
                conceal = conceal,
                undo_restore = false,
                _conceal_continuation = conceal ~= false and (sr ~= start_row or sc ~= start_col),
                priority = priority,
              })
            end
          end
        end
      end
    end

    state.next_row = next_row
    state.next_col = next_col
    if cmp_lt(next_row, next_col, skip_until_row, skip_until_col) then
      skip_until_row = next_row
      skip_until_col = next_col
    end
  end)
  return skip_until_row, skip_until_col
end

---@private
---@param buf integer
---@param br integer
---@param bc integer
---@param er integer
---@param ec integer
function TSHighlighter._on_range(_, _, buf, br, bc, er, ec, _)
  local self = TSHighlighter.active[buf]
  if not self then
    return
  end

  return on_range_impl(self, buf, br, bc, er, ec, false, false)
end

---@private
---@param buf integer
---@param srow integer
---@param erow integer
function TSHighlighter._on_spell_nav(_, _, buf, srow, _, erow, _)
  local self = TSHighlighter.active[buf]
  if not self then
    return
  end

  -- Do not affect potentially populated highlight state. Here we just want a temporary
  -- empty state so the C code can detect whether the region should be spell checked.
  local highlight_states = self._highlight_states
  local search_erow = math.max(erow, srow + 1)
  self:prepare_highlight_states(srow, erow)

  on_range_impl(self, buf, srow, 0, search_erow, 0, true, false)
  self._highlight_states = highlight_states
end

---@private
--- Adds the conceal of row `row` to the marktree, after parsing the row: `conceal_lines`, and
--- intra-line conceal for 'wrap' (see `nvim__buf_set_conceal_provider()`).
---@param win integer
---@param buf integer
---@param row integer
function TSHighlighter._on_conceal(event, win, buf, row)
  local self = TSHighlighter.active[buf]
  local checked = self and self._conceal_checked[row]
  if not self or checked then
    return
  end
  -- Under 'wrap' both events run, `conceal_line` first; under 'nowrap' it needs only
  -- `conceal_lines`.
  local intra = self._has_conceal and (event == 'conceal' or vim.wo[win].wrap)
  if not (intra or self._has_conceal_line) or (checked == false and not intra) then
    return
  end

  -- Do not affect potentially populated highlight state.
  local highlight_states = self._highlight_states
  self.tree:parse({ row, row + 1 })
  self._conceal_checked[row] = intra
  -- Replace the row's marks, which an edit may have moved here.
  local marks = api.nvim_buf_get_extmarks(
    buf,
    ns,
    { row, 0 },
    { row, -1 },
    { overlap = true, details = true }
  )
  api.nvim_buf_clear_namespace(buf, ns, row, row + 1)
  api.nvim_buf_clear_namespace(buf, conceal_ns, row, row + 1)
  self:prepare_highlight_states(row, row)
  on_range_impl(self, buf, row, 0, row + 1, 0, false, true, intra)
  -- This row's query need not return the capture of a `conceal_lines` mark that spans other rows
  -- (e.g. moved by `#offset!`, or shrunk by an edit there): query its rows.
  for _, mark in ipairs(marks) do
    local srow, erow = mark[2], assert(mark[4]).end_row or mark[2]
    if #api.nvim_buf_get_extmarks(buf, ns, { srow, 0 }, { srow, 0 }, {}) == 0 then
      self.tree:parse({ srow, erow + 1 })
      self:prepare_highlight_states(srow, erow)
      on_range_impl(self, buf, srow, 0, erow + 1, 0, false, true)
    end
  end
  self._highlight_states = highlight_states
end

---@private
---@param buf integer
---@param topline integer
---@param botline integer
function TSHighlighter._on_win(_, _, buf, topline, botline)
  local self = TSHighlighter.active[buf]
  if not self then
    return false
  end
  if not self.parsing then
    self.redraw_count = self.redraw_count + 1
    self:prepare_highlight_states(topline, botline)
  else
    self:for_each_highlight_state(function(state)
      state.iter = nil
      state.next_row = 0
      state.next_col = 0
    end)
  end
  return next(self._highlight_states) ~= nil
end

function TSHighlighter._on_start()
  local buf_ranges = {} ---@type table<integer, Range[]>
  local buf_conceal = {} ---@type table<integer, boolean>
  for _, win in ipairs(api.nvim_tabpage_list_wins(0)) do
    local buf = api.nvim_win_get_buf(win)
    if TSHighlighter.active[buf] then
      if not buf_ranges[buf] then
        buf_ranges[buf] = {}
      end
      buf_conceal[buf] = buf_conceal[buf] or vim.wo[win].wrap and vim.wo[win].conceallevel > 0
      local topline = vim.fn.line('w0', win) - 1
      -- +1 because w$ is the last completely displayed line (w_botline - 1), which may be -1 of the
      -- last line that is at least partially visible.
      local botline = vim.fn.line('w$', win) + 1
      table.insert(buf_ranges[buf], { topline, botline })
    end
  end
  for buf, ranges in pairs(buf_ranges) do
    local highlighter = TSHighlighter.active[buf]
    if not highlighter.parsing then
      table.sort(ranges, function(a, b)
        return a[1] < b[1]
      end)
      if highlighter._has_conceal and buf_conceal[buf] then
        -- Conceal sets the 'wrap' layout, which must not wait for an async parse.
        highlighter.tree:parse(ranges)
      else
        highlighter.parsing = highlighter.parsing
          or nil
            == highlighter.tree:parse(ranges, function(_, trees)
              if trees and highlighter.parsing and TSHighlighter.active[buf] == highlighter then
                highlighter.parsing = false
                api.nvim__redraw({ buf = buf, valid = false, flush = false })
              end
            end)
      end
    end
  end
end

api.nvim_set_decoration_provider(ns, {
  on_win = TSHighlighter._on_win,
  on_start = TSHighlighter._on_start,
  on_range = TSHighlighter._on_range,
  _on_spell_nav = TSHighlighter._on_spell_nav,
  _on_conceal_line = TSHighlighter._on_conceal,
  _on_conceal = TSHighlighter._on_conceal,
})

return TSHighlighter
